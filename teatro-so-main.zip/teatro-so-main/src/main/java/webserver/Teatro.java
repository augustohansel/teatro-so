package webserver;

public class Teatro {
    private int idcadeira;
    private boolean status;

    public int getIdCadeira() {
        return idcadeira;
    }

    public void setIdCadeira(int idcadeira) {
        this.idcadeira = idcadeira;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
